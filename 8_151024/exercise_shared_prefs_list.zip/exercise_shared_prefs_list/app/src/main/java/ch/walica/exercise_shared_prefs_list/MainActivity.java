package ch.walica.exercise_shared_prefs_list;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private RadioGroup radioGroup;
    private TextView tvCounter;
    private Button btnClear, btnClose;
    private String[] programingLanguage = {"JavaScript", "TypeScript", "PHP", "Python", "Java"};

    private int color = R.id.rbRed;
    private int counter = 0;

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        radioGroup = findViewById(R.id.radioGroup);
        tvCounter = findViewById(R.id.tvCounter);
        btnClear = findViewById(R.id.btnClear);
        btnClose = findViewById(R.id.btnClose);


        sharedPreferences = getSharedPreferences("shared_prefs_1", MODE_PRIVATE);


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, programingLanguage);
        color = sharedPreferences.getInt("color_key", R.id.rbRed);
        counter = sharedPreferences.getInt("counter_key", 0);

        tvCounter.setText(String.valueOf(counter));
        radioGroup.check(color);
        serDividerColor();

        listView.setAdapter(adapter);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                color = checkedId;
                serDividerColor();
                sharedPreferences.edit().putInt("color_key", color).apply();
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                counter++;
                tvCounter.setText(String.valueOf(counter));
                sharedPreferences.edit().putInt("counter_key", counter).apply();
            }
        });

        btnClear.setOnClickListener(view -> {
            sharedPreferences.edit().clear().apply();
            color = R.id.rbRed;
            counter = 0;
            radioGroup.check(color);
            tvCounter.setText(String.valueOf(counter));
            serDividerColor();
        });

        btnClose.setOnClickListener(view -> {
            finish();
        });

    }

    private void serDividerColor() {
        if (color == R.id.rbRed) {
            listView.setDivider(new ColorDrawable(Color.RED));
            tvCounter.setTextColor(Color.RED);
        } else {
            listView.setDivider(new ColorDrawable(Color.BLUE));
            tvCounter.setTextColor(Color.BLUE);
        }
        listView.setDividerHeight(3);
    }
}