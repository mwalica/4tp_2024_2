package ch.walica.temp70125_4tp_2_glide;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    ImageView ivPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ivPhoto = findViewById(R.id.ivPhoto);

        ivPhoto.setOnClickListener(v -> {
            Glide
                    .with(MainActivity.this)
                    .load("https://images.pexels.com/photos/30007672/pexels-photo-30007672/free-photo-of-vibrant-carmine-bee-eater-perched-on-a-branch.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2")
                    .centerCrop()
                    .placeholder(R.drawable.photo_1)
                    .into(ivPhoto);
        });
    }
}