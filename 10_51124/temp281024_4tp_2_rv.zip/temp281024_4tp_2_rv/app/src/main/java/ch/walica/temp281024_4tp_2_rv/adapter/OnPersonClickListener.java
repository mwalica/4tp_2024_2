package ch.walica.temp281024_4tp_2_rv.adapter;

public interface OnPersonClickListener {
    void onPersonClick(int position);
}
