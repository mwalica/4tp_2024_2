package ch.walica.temp281024_4tp_2_rv;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.DataOutputStream;
import java.util.ArrayList;
import java.util.List;

import ch.walica.temp281024_4tp_2_rv.adapter.OnPersonClickListener;
import ch.walica.temp281024_4tp_2_rv.adapter.PersonAdapter;
import ch.walica.temp281024_4tp_2_rv.model.Person;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FloatingActionButton floatingActionButton;
    private List<Person> persons = new ArrayList();
    private PersonAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.recyclerView);
        floatingActionButton = findViewById(R.id.floatingActionButton);

        persons.add(new Person("Franek"));
        persons.add(new Person("Janek"));
        persons.add(new Person("Zenek"));
        persons.add(new Person("Adam"));
        persons.add(new Person("Karol"));

        adapter = new PersonAdapter(persons, new OnPersonClickListener() {
            @Override
            public void onPersonClick(int position) {
                persons.remove(position);
                adapter.notifyItemRemoved(position);
                adapter.notifyItemRangeChanged(position, persons.size());
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        recyclerView.setAdapter(adapter);


        floatingActionButton.setOnClickListener(v -> {
            View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.edit_text_layout, null);
            EditText etName = view.findViewById(R.id.etName);

            new MaterialAlertDialogBuilder(this)
                    .setTitle("Dodaj osobę")
                    .setView(view)
                    .setPositiveButton("Dodaj", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String name = etName.getText().toString().trim();
                            if(!name.isEmpty()) {
                                persons.add(new Person(name));
                                adapter.notifyDataSetChanged();
                            }
                        }
                    })
                    .setNegativeButton("Anuluj", null)
                    .show();
        });
    }
}