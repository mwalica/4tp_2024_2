package ch.walica.temp170924_4tp_2_scroll_list.model;

import androidx.annotation.NonNull;

import java.util.Random;

public class Person {

    private String name;
    private int age;
    private Random random = new Random();

    public Person(String name) {
        this.name = name;
        this.age = random.nextInt(80) + 18;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @NonNull
    @Override
    public String toString() {
        return name + ", " + age;
    }
}
