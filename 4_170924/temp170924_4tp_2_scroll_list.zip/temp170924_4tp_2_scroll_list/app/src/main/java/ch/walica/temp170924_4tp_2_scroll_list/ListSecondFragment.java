package ch.walica.temp170924_4tp_2_scroll_list;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import ch.walica.temp170924_4tp_2_scroll_list.model.Person;


public class ListSecondFragment extends Fragment {

    private ListView listView2;
    private String[] names = {
            "Jan",
            "Karol",
            "Dominik",
            "Zuzanna",
            "Ilona",
            "Kazimierz",
            "Jan",
            "Karol",
            "Dominik",
            "Zuzanna",
            "Ilona",
            "Kazimierz",
            "Jan",
            "Karol",
            "Dominik",
            "Zuzanna",
            "Ilona",
            "Kazimierz"
    };

    List<Person> persons = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_list_second, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        persons.add(new Person("Karol"));
        persons.add(new Person("Jan"));
        persons.add(new Person("Adam"));

        listView2 = view.findViewById(R.id.listView2);
//        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(requireActivity(), android.R.layout.simple_list_item_1, names);
//        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(requireActivity(), R.layout.name_item_1, R.id.tvName1, names);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(requireActivity(), R.layout.name_item_2, names);
        ArrayAdapter<Person> adapter2 = new ArrayAdapter<>(requireActivity(), R.layout.name_item_2, persons);

        listView2.setAdapter(adapter2);

        listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(requireContext(), "Kliknięte: " + persons.get(i).getName(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}