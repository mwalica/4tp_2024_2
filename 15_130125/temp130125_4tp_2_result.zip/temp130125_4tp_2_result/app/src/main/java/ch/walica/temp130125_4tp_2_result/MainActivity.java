package ch.walica.temp130125_4tp_2_result;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView tvResult1;
    Button btnToSecond;
    ActivityResultLauncher<String> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        launcher = registerForActivityResult(new ActivityResultContract<String, String>() {
                                                 @Override
                                                 public String parseResult(int resultState, @Nullable Intent intent) {
                                                     if (resultState == RESULT_OK) {
                                                         return intent.getStringExtra("uppercase_key");
                                                     }
                                                     return "";
                                                 }

                                                 @NonNull
                                                 @Override
                                                 public Intent createIntent(@NonNull Context context, String name) {
                                                     return new Intent(context, SecondActivity.class).putExtra("name_key", name);
                                                 }
                                             },
                new ActivityResultCallback<String>() {
                    @Override
                    public void onActivityResult(String res) {
                        tvResult1.setText(res);
                    }
                });

        tvResult1 = findViewById(R.id.tvResult1);
        btnToSecond = findViewById(R.id.btnToSecond);

        btnToSecond.setOnClickListener(v -> {
            launcher.launch("tadeusz");
        });
    }
}