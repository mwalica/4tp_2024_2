package ch.walica.temp10924_4tp_2sharedprefernces;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class MainActivity extends AppCompatActivity {

    private EditText etName;
    private TextView tvResult;
    private Button btnSave;
    private SwitchMaterial switchMaterial;
    private ConstraintLayout main;

    private String name = "";
    private boolean isDark = false;

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        tvResult = findViewById(R.id.tvResult);
        btnSave = findViewById(R.id.btnSave);
        switchMaterial = findViewById(R.id.switchMaterial);
        main = findViewById(R.id.main);

        sharedPreferences = getSharedPreferences("app_prefs_1", MODE_PRIVATE);

        name = sharedPreferences.getString("name_key", "");
        isDark = sharedPreferences.getBoolean("switch_key", false);

        tvResult.setText(name);
        switchMaterial.setChecked(isDark);

        if(isDark) {
            main.setBackgroundColor(getColor(R.color.grey));
        } else {
            main.setBackgroundColor(getColor(R.color.white));
        }

        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                name = charSequence.toString();
                tvResult.setText(name);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        switchMaterial.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean checked) {
                isDark = checked;
                if(isDark) {
                    main.setBackgroundColor(getColor(R.color.grey));
                } else {
                    main.setBackgroundColor(getColor(R.color.white));
                }
            }
        });

        btnSave.setOnClickListener(view -> {
            sharedPreferences.edit().putString("name_key", name).putBoolean("switch_key", isDark).apply();
            Toast.makeText(this, "Ustawienia zapisane", Toast.LENGTH_SHORT).show();
        });

        tvResult.setOnClickListener(view -> {
            sharedPreferences.edit().clear().apply();
            name = "";
            isDark = false;
            tvResult.setText(name);
            switchMaterial.setChecked(isDark);

            if(isDark) {
                main.setBackgroundColor(getColor(R.color.grey));
            } else {
                main.setBackgroundColor(getColor(R.color.white));
            }
        });

    }
}