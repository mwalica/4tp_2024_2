package ch.walica.temp291024_4tp_2_layoutmanager.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import ch.walica.temp291024_4tp_2_layoutmanager.R;

public class CarAdapter extends RecyclerView.Adapter<CarAdapter.CarViewHolder>{

    private String[] cars;

    public CarAdapter(String[] cars) {
        this.cars = cars;
    }

    @NonNull
    @Override
    public CarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.car_item, parent, false);
        return new CarViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CarViewHolder holder, int position) {
        holder.bind(cars[position]);
    }

    @Override
    public int getItemCount() {
        return cars.length;
    }


    //viewholder

    public class CarViewHolder extends RecyclerView.ViewHolder {

        TextView tvCarName;

        public CarViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCarName = itemView.findViewById(R.id.tvCarName);
        }

        public void bind(String name) {
            tvCarName.setText(name);
        }
    }
}
