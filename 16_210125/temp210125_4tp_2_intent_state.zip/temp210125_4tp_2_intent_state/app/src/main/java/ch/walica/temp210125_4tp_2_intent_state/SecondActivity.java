package ch.walica.temp210125_4tp_2_intent_state;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ch.walica.temp210125_4tp_2_intent_state.models.Person;

public class SecondActivity extends AppCompatActivity {

    TextView tvResul;
    Button btnBack;
    String firstName = "";
    int age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvResul = findViewById(R.id.tvResult);
        btnBack = findViewById(R.id.btnBack);

//        if(getIntent().hasExtra("name_key") && getIntent().hasExtra("age_key")) {
//            firstName = getIntent().getStringExtra("name_key");
//            age = getIntent().getIntExtra("age_key", 0);
//            tvResul.setText(firstName + " " + age);
//        }

        if(getIntent().hasExtra("person_key")) {
            Person person = (Person) getIntent().getSerializableExtra("person_key");
            firstName = person.getFirstName();
            age = person.getAge();
            tvResul.setText(firstName + " " + age);
        }


        btnBack.setOnClickListener(view -> {
            finish();
        });

    }
}