package ch.walica.temp210125_4tp_2_intent_state;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

import ch.walica.temp210125_4tp_2_intent_state.models.Person;

public class MainActivity extends AppCompatActivity {

    EditText etFirstName;
    Button btnSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        etFirstName = findViewById(R.id.etFirstName);
        btnSend = findViewById(R.id.btnSend);

        btnSend.setOnClickListener(view -> {
            String firstName = etFirstName.getText().toString().trim();
            if(!firstName.isEmpty()) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
//                intent.putExtra("name_key", firstName);
//                intent.putExtra("age_key", new Random().nextInt(81) + 18);
                intent.putExtra("person_key", new Person(firstName));
                startActivity(intent);
            }

        });

    }
}