package ch.walica.temp210125_4tp_2_intent_state.models;

import java.io.Serializable;
import java.util.Random;

public class Person implements Serializable {
    private String firstName;
    private int age;

    public Person(String firstName, int age) {
        this.firstName = firstName;
        this.age = age;
    }

    public Person(String firstName) {
        this.firstName = firstName;
        this.age = new Random().nextInt(81) + 18;
    }

    public String getFirstName() {
        return firstName;
    }

    public int getAge() {
        return age;
    }
}
